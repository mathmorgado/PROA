package AulaDebora.com.PrimeiroProjeto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PrimeiroProjetoApplicationTests {

	@Test
	void contextLoads() {
	}

}
